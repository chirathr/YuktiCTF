<?php
$email=$_POST['email'];
$password=$_POST['password'];
if($email=="admin@ctf.com" and  $password=="Well_Done"){
    echo "flag{Sh0uld_S3e_C00k1es}";
    }
else echo "Better Luck next time";

?>