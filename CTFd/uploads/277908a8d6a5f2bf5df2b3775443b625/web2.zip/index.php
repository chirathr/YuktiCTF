<!DOCTYPE html>
<?php
$cookie_name = "Credentials";
$cookie_value = "email='admin@ctf.com' && password='Well_Done'";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
?>
<html >
<head>
  <meta charset="UTF-8">
  <title>Login</title>
      <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div id="wrap">
  <div id="regbar">
    <div id="navthing">
      <h2><a href="#" id="loginform">Login</a></h2> 
    <div class="login">
      <div class="arrow-up"></div>
      <div class="formholder">
        <div class="randompad">
           <fieldset>
           <form method="POST" action="flag.php"> 
             <label name="email">email</label>
             <input name="email" type="email" />
             <label name="password">Password</label>
             <input name="password" type="password" />
             <input type="submit" value="Login" />
             </form>
           </fieldset>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>

</body>
</html>
